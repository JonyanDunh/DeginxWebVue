<script>

var user;
var is_login=false;
var page;
export default {

  user,
  is_login,
  page
}
</script>